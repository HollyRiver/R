
rm(list = ls(all=T)) # This code clears all. 
load("F:\\teaching\\Econometrics\\R\\OLS\\mlb1.RData") #load data

ls(data) #list of variables
head(data)

head(data$lsalary)
# dependent variable
lsalary <- data$lsalary #log(salary) variable

#explanatory variables
years <- data$years     #years of experience
gamesyr <- data$gamesyr #average games each year
bavg <- data$bavg       #batting average
hrunsyr <-data$hrunsyr  #home runs  
rbisyr <-data$rbisyr    #run batted in

#plot--------------------------------------------------------------
dev.new()
plot(rbisyr,lsalary,  pch=16, col="blue", cex=1.5, )


#Scatter Plot------------------------------------------------------
mlb.data<-data.frame(years, gamesyr, bavg, hrunsyr, rbisyr,lsalary)
dev.new()
pairs(mlb.data, col="blue", pch=16, cex=1.25, cex.axis=1.25)

#-------------Correlation plot-------------------------------------
install.packages("corrplot")
library(corrplot)
cor.mat<-cor(mlb.data)
cor.mat
dev.new()
corrplot.mixed(cor.mat, lower="number", upper="circle")

#-------------Homework------------------------------------------
# Do not use the lm() function. Answer the following questions

#1. Compute the betas (beta0,...,beta5).

#2. Compute the variance of the betas.

#3. Compute the t-values for the betas.

#4. Compute the p-values for the betas. 
#---------------------------------------------------------------